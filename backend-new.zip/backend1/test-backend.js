const axios = require('axios');
const colors = require('colors');
const fs = require('fs');
const path = require('path');

// Configuration
const API_BASE_URL = 'http://localhost:5000/api';
let authToken = '';
let testUserId = '';
let testResourceId = '';
let testBookingId = '';
let testNotificationId = '';

// Test results
const testResults = {
    passed: 0,
    failed: 0,
    total: 0,
    details: []
};

// Helper function to log test results
function logTest(testName, success, message = '') {
    testResults.total++;
    if (success) {
        testResults.passed++;
        console.log(`✅ ${testName}`.green);
        if (message) console.log(`   ${message}`.gray);
    } else {
        testResults.failed++;
        console.log(`❌ ${testName}`.red);
        if (message) {
            if (typeof message === 'object') {
                console.log(`   ${JSON.stringify(message, null, 2)}`.red);
            } else {
                console.log(`   ${message}`.red);
            }
        }
    }
    
    testResults.details.push({
        test: testName,
        success,
        message: typeof message === 'object' ? JSON.stringify(message) : message
    });
}

// Helper function to make API requests with delay
async function apiRequest(method, endpoint, data = null, headers = {}) {
    try {
        const config = {
            method,
            url: `${API_BASE_URL}${endpoint}`,
            headers: {
                'Content-Type': 'application/json',
                ...headers
            },
            timeout: 10000
        };
        
        if (data) {
            config.data = data;
        }
        
        console.log(`🔍 Making ${method} request to: ${config.url}`);
        
        const response = await axios(config);
        return { success: true, data: response.data, status: response.status };
    } catch (error) {
        console.log(`❌ Request failed: ${error.message}`);
        return { 
            success: false, 
            error: error.response ? error.response.data : error.message,
            status: error.response ? error.response.status : 500,
            details: error
        };
    }
}

// Helper function to add delay between requests
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Helper function to get future date
function getFutureDate(daysFromNow = 7) {
    const date = new Date();
    date.setDate(date.getDate() + daysFromNow);
    return date.toISOString().split('T')[0];
}

// Test functions
async function testHealthCheck() {
    const result = await apiRequest('GET', '/health');
    logTest('Health Check', result.success, result.success ? 'API is running' : result.error);
}

async function testAuth() {
    console.log('\n=== Testing Authentication ==='.cyan);
    
    // Generate unique email for testing
    const timestamp = Date.now();
    const testEmail = `test${timestamp}@example.com`;
    
    // Test registration - FIXED: Using correct field names (fullName, facultyId)
    const registrationData = {
        fullName: 'Test User',  // ← Changed from full_name to fullName
        email: testEmail,
        password: 'password123',
        facultyId: `TEST${timestamp}`,  // ← Changed from registration_no to facultyId
        department: 'Computer Science',
        faculty: 'Engineering',
        academic_year: '2023-2024',
        phone: '077-1234567'
    };
    
    const registerResult = await apiRequest('POST', '/auth/register', registrationData);
    logTest('User Registration', registerResult.success, registerResult.success ? 'User registered successfully' : registerResult.error);
    
    if (registerResult.success) {
        // FIXED: Extract user_id from different possible response structures
        testUserId = registerResult.data.data?.user?.user_id || 
                   registerResult.data.data?.user?.id || 
                   registerResult.data.user?.user_id ||
                   registerResult.data.user?.id;
    }
    
    await delay(500);
    
    // Test login
    const loginData = {
        email: testEmail,
        password: 'password123'
    };
    
    const loginResult = await apiRequest('POST', '/auth/login', loginData);
    logTest('User Login', loginResult.success, loginResult.success ? 'User logged in successfully' : loginResult.error);
    
    if (loginResult.success) {
        // FIXED: Extract token from different possible response structures
        authToken = loginResult.data.data?.token || 
                   loginResult.data.token;
    }
    
    await delay(500);
    
    // Test get profile
    const profileResult = await apiRequest('GET', '/auth/me', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get User Profile', profileResult.success, profileResult.success ? 'Profile retrieved successfully' : profileResult.error);
    
    await delay(500);
    
    // Test update profile
    const updateData = {
        full_name: 'Updated Test User',
        phone: '077-7654321'
    };
    
    const updateResult = await apiRequest('PUT', '/auth/me', updateData, { 'Authorization': `Bearer ${authToken}` });
    logTest('Update Profile', updateResult.success, updateResult.success ? 'Profile updated successfully' : updateResult.error);
    
    await delay(500);
    
    // Test change password
    const passwordData = {
        currentPassword: 'password123',
        newPassword: 'newpassword123'
    };
    
    const passwordResult = await apiRequest('PUT', '/auth/change-password', passwordData, { 'Authorization': `Bearer ${authToken}` });
    logTest('Change Password', passwordResult.success, passwordResult.success ? 'Password changed successfully' : passwordResult.error);
    
    await delay(500);
    
    // Test logout
    const logoutResult = await apiRequest('POST', '/auth/logout', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('User Logout', logoutResult.success, logoutResult.success ? 'User logged out successfully' : logoutResult.error);
}

async function testResources() {
    console.log('\n=== Testing Resources ==='.cyan);
    
    // Login again to get a fresh token
    const timestamp = Date.now();
    const testEmail = `test${timestamp}@example.com`;
    
    // Register and login a new user - FIXED: Using correct field names
    const registrationData = {
        fullName: 'Test User 2',  // ← Changed from full_name to fullName
        email: testEmail,
        password: 'password123',
        facultyId: `TEST2${timestamp}`,  // ← Changed from registration_no to facultyId
        department: 'Computer Science',
        faculty: 'Engineering',
        academic_year: '2023-2024',
        phone: '077-1234567'
    };
    
    await apiRequest('POST', '/auth/register', registrationData);
    await delay(500);
    
    const loginResult = await apiRequest('POST', '/auth/login', {
        email: testEmail,
        password: 'password123'
    });
    
    if (loginResult.success) {
        authToken = loginResult.data.data?.token || loginResult.data.token;
    }
    
    await delay(500);
    
    // Test get all resources
    const resourcesResult = await apiRequest('GET', '/resources', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get All Resources', resourcesResult.success, resourcesResult.success ? 'Resources retrieved successfully' : resourcesResult.error);
    
    // FIXED: Extract resource_id from different possible response structures
    if (resourcesResult.success && resourcesResult.data.data && resourcesResult.data.data.length > 0) {
        testResourceId = resourcesResult.data.data[0].resource_id || resourcesResult.data.data[0].id;
    } else if (resourcesResult.success && resourcesResult.data.resources && resourcesResult.data.resources.length > 0) {
        testResourceId = resourcesResult.data.resources[0].resource_id || resourcesResult.data.resources[0].id;
    }
    
    await delay(500);
    
    // Test get resource by ID
    if (testResourceId) {
        const resourceResult = await apiRequest('GET', `/resources/${testResourceId}`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Get Resource by ID', resourceResult.success, resourceResult.success ? 'Resource retrieved successfully' : resourceResult.error);
    }
    
    await delay(500);
    
    // Test get resource statistics
    const statsResult = await apiRequest('GET', '/resources/stats', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Resource Statistics', statsResult.success, statsResult.success ? 'Statistics retrieved successfully' : statsResult.error);
    
    await delay(500);
    
    // Test get available resources
    const availableResult = await apiRequest('GET', `/resources/available?date=${getFutureDate()}&start_time=14:00&end_time=16:00`, null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Available Resources', availableResult.success, availableResult.success ? 'Available resources retrieved successfully' : availableResult.error);
    
    await delay(500);
    
    // Test get resources by type
    const typeResult = await apiRequest('GET', '/resources/type/laboratory', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Resources by Type', typeResult.success, typeResult.success ? 'Resources by type retrieved successfully' : typeResult.error);
    
    await delay(500);
    
    // Test get resources by faculty
    const facultyResult = await apiRequest('GET', '/resources/faculty/engineering', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Resources by Faculty', facultyResult.success, facultyResult.success ? 'Resources by faculty retrieved successfully' : facultyResult.error);
}

async function testBookings() {
    console.log('\n=== Testing Bookings ==='.cyan);
    
    await delay(500);
    
    // Test create booking - FIXED: Use different time slot to avoid conflicts
    if (testResourceId) {
        const bookingData = {
            resource_id: testResourceId,
            title: 'Test Booking',
            date: getFutureDate(),
            start_time: '14:00', // Changed from 10:00 to avoid conflicts
            end_time: '16:00',   // Changed from 12:00 to avoid conflicts
            reason: 'workshop',
            purpose: 'Testing the booking system',
            requirements: 'Projector and whiteboard',
            attendees: 10
        };
        
        const createResult = await apiRequest('POST', '/bookings', bookingData, { 'Authorization': `Bearer ${authToken}` });
        logTest('Create Booking', createResult.success, createResult.success ? 'Booking created successfully' : createResult.error);
        
        if (createResult.success) {
            // FIXED: Extract booking_id from different possible response structures
            testBookingId = createResult.data.data?.booking_id || 
                         createResult.data.data?.id || 
                         createResult.data.booking?.booking_id ||
                         createResult.data.booking?.id;
        }
    }
    
    await delay(500);
    
    // Test get all bookings
    const bookingsResult = await apiRequest('GET', '/bookings', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get All Bookings', bookingsResult.success, bookingsResult.success ? 'Bookings retrieved successfully' : bookingsResult.error);
    
    await delay(500);
    
    // Test get booking by ID
    if (testBookingId) {
        const bookingResult = await apiRequest('GET', `/bookings/${testBookingId}`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Get Booking by ID', bookingResult.success, bookingResult.success ? 'Booking retrieved successfully' : bookingResult.error);
    }
    
    await delay(500);
    
    // Test update booking
    if (testBookingId) {
        const updateData = {
            title: 'Updated Test Booking',
            attendees: 15
        };
        
        const updateResult = await apiRequest('PUT', `/bookings/${testBookingId}`, updateData, { 'Authorization': `Bearer ${authToken}` });
        logTest('Update Booking', updateResult.success, updateResult.success ? 'Booking updated successfully' : updateResult.error);
    }
    
    await delay(500);
    
    // Test get booking statistics
    const statsResult = await apiRequest('GET', '/bookings/stats', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Booking Statistics', statsResult.success, statsResult.success ? 'Statistics retrieved successfully' : statsResult.error);
    
    await delay(500);
    
    // Test get upcoming bookings
    const upcomingResult = await apiRequest('GET', '/bookings/upcoming', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Upcoming Bookings', upcomingResult.success, upcomingResult.success ? 'Upcoming bookings retrieved successfully' : upcomingResult.error);
    
    await delay(500);
    
    // Test get today's bookings
    const todayResult = await apiRequest('GET', '/bookings/today', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Today\'s Bookings', todayResult.success, todayResult.success ? 'Today\'s bookings retrieved successfully' : todayResult.error);
    
    await delay(500);
    
    // Test cancel booking
    if (testBookingId) {
        const cancelResult = await apiRequest('PUT', `/bookings/${testBookingId}/cancel`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Cancel Booking', cancelResult.success, cancelResult.success ? 'Booking cancelled successfully' : cancelResult.error);
    }
}

async function testNotifications() {
    console.log('\n=== Testing Notifications ==='.cyan);
    
    await delay(500);
    
    // Test get all notifications
    const notificationsResult = await apiRequest('GET', '/notifications', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get All Notifications', notificationsResult.success, notificationsResult.success ? 'Notifications retrieved successfully' : notificationsResult.error);
    
    // FIXED: Extract notification_id from different possible response structures
    if (notificationsResult.success && notificationsResult.data.data && notificationsResult.data.data.length > 0) {
        testNotificationId = notificationsResult.data.data[0].notification_id || notificationsResult.data.data[0].id;
    } else if (notificationsResult.success && notificationsResult.data.notifications && notificationsResult.data.notifications.length > 0) {
        testNotificationId = notificationsResult.data.notifications[0].notification_id || notificationsResult.data.notifications[0].id;
    }
    
    await delay(500);
    
    // Test get unread count
    const unreadResult = await apiRequest('GET', '/notifications/unread-count', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Unread Count', unreadResult.success, unreadResult.success ? 'Unread count retrieved successfully' : unreadResult.error);
    
    await delay(500);
    
    // Test get recent notifications
    const recentResult = await apiRequest('GET', '/notifications/recent?limit=5', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Recent Notifications', recentResult.success, recentResult.success ? 'Recent notifications retrieved successfully' : recentResult.error);
    
    await delay(500);
    
    // Test mark notification as read
    if (testNotificationId) {
        const markResult = await apiRequest('PUT', `/notifications/${testNotificationId}/read`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Mark Notification as Read', markResult.success, markResult.success ? 'Notification marked as read' : markResult.error);
    }
    
    await delay(500);
    
    // Test mark all notifications as read
    const markAllResult = await apiRequest('PUT', '/notifications/read-all', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Mark All Notifications as Read', markAllResult.success, markAllResult.success ? 'All notifications marked as read' : markAllResult.error);
}

async function testDashboard() {
    console.log('\n=== Testing Dashboard ==='.cyan);
    
    await delay(500);
    
    // Test get dashboard stats
    const statsResult = await apiRequest('GET', '/dashboard/stats', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Dashboard Stats', statsResult.success, statsResult.success ? 'Dashboard stats retrieved successfully' : statsResult.error);
    
    await delay(500);
    
    // Test get recent activity
    const activityResult = await apiRequest('GET', '/dashboard/recent-activity', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Recent Activity', activityResult.success, activityResult.success ? 'Recent activity retrieved successfully' : activityResult.error);
    
    await delay(500);
    
    // Test get upcoming bookings
    const upcomingResult = await apiRequest('GET', '/dashboard/upcoming-bookings', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Dashboard Upcoming Bookings', upcomingResult.success, upcomingResult.success ? 'Upcoming bookings retrieved successfully' : upcomingResult.error);
    
    await delay(500);
    
    // Test get resource utilization
    const utilizationResult = await apiRequest('GET', '/dashboard/resource-utilization', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Resource Utilization', utilizationResult.success, utilizationResult.success ? 'Resource utilization retrieved successfully' : utilizationResult.error);
    
    await delay(500);
    
    // Test get quick stats
    const quickResult = await apiRequest('GET', '/dashboard/quick-stats', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get Quick Stats', quickResult.success, quickResult.success ? 'Quick stats retrieved successfully' : quickResult.error);
    
    await delay(500);
    
    // Test get user dashboard
    const userResult = await apiRequest('GET', '/dashboard/user', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get User Dashboard', userResult.success, userResult.success ? 'User dashboard retrieved successfully' : userResult.error);
}

async function testAvailability() {
    console.log('\n=== Testing Availability ==='.cyan);
    
    await delay(500);
    
    if (testResourceId) {
        // Test check availability
        const checkResult = await apiRequest('GET', `/availability/check?resource_id=${testResourceId}&date=${getFutureDate()}&start_time=14:00&end_time=16:00`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Check Resource Availability', checkResult.success, checkResult.success ? 'Availability checked successfully' : checkResult.error);
        
        await delay(500);
        
        // Test get available resources
        const availableResult = await apiRequest('GET', `/availability/resources?date=${getFutureDate()}&start_time=14:00&end_time=16:00`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Get Available Resources', availableResult.success, availableResult.success ? 'Available resources retrieved successfully' : availableResult.error);
        
        await delay(500);
        
        // Test get resource schedule
        const scheduleResult = await apiRequest('GET', `/availability/schedule?resource_id=${testResourceId}&start_date=${getFutureDate()}&end_date=${getFutureDate()}`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Get Resource Schedule', scheduleResult.success, scheduleResult.success ? 'Resource schedule retrieved successfully' : scheduleResult.error);
    }
}

async function testUsers() {
    console.log('\n=== Testing Users ==='.cyan);
    
    await delay(500);
    
    // Test get all users (will fail for non-admin)
    const usersResult = await apiRequest('GET', '/users', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get All Users', usersResult.status === 403 ? true : usersResult.success, usersResult.status === 403 ? 'Correctly denied access for non-admin' : (usersResult.success ? 'Users retrieved successfully' : usersResult.error));
    
    await delay(500);
    
    // Test get user by ID
    if (testUserId) {
        const userResult = await apiRequest('GET', `/users/${testUserId}`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Get User by ID', userResult.success, userResult.success ? 'User retrieved successfully' : userResult.error);
    }
    
    await delay(500);
    
    // Test get user statistics (will fail for non-admin)
    const statsResult = await apiRequest('GET', '/users/stats', null, { 'Authorization': `Bearer ${authToken}` });
    logTest('Get User Statistics', statsResult.status === 403 ? true : statsResult.success, statsResult.status === 403 ? 'Correctly denied access for non-admin' : (statsResult.success ? 'Statistics retrieved successfully' : statsResult.error));
    
    await delay(500);
    
    // Test get user bookings - FIXED: Include user ID in the endpoint
    if (testUserId) {
        const bookingsResult = await apiRequest('GET', `/users/${testUserId}/bookings`, null, { 'Authorization': `Bearer ${authToken}` });
        logTest('Get User Bookings', bookingsResult.success, bookingsResult.success ? 'User bookings retrieved successfully' : bookingsResult.error);
    } else {
        logTest('Get User Bookings', false, 'User ID not available');
    }
}

async function generateReport() {
    console.log('\n=== Test Report ==='.cyan.bold);
    
    const successRate = ((testResults.passed / testResults.total) * 100).toFixed(2);
    
    console.log(`Total Tests: ${testResults.total}`);
    console.log(`Passed: ${testResults.passed.toString().green}`);
    console.log(`Failed: ${testResults.failed.toString().red}`);
    console.log(`Success Rate: ${successRate}%`);
    
    // Create detailed report
    const report = {
        timestamp: new Date().toISOString(),
        summary: {
            total: testResults.total,
            passed: testResults.passed,
            failed: testResults.failed,
            successRate: successRate
        },
        details: testResults.details
    };
    
    // Save report to file
    fs.writeFileSync(
        path.join(__dirname, 'test-report.json'),
        JSON.stringify(report, null, 2)
    );
    
    console.log('\nDetailed report saved to test-report.json');
    
    // Print failed tests
    const failedTests = testResults.details.filter(test => !test.success);
    if (failedTests.length > 0) {
        console.log('\n=== Failed Tests ==='.red.bold);
        failedTests.forEach(test => {
            console.log(`${test.test}: ${test.message}`.red);
        });
    }
}

// Main test function
async function runTests() {
    console.log('=== Starting Backend API Tests ==='.cyan.bold);
    
    try {
        await testHealthCheck();
        await testAuth();
        await testResources();
        await testBookings();
        await testNotifications();
        await testDashboard();
        await testAvailability();
        await testUsers();
        
        await generateReport();
        
        if (testResults.failed > 0) {
            console.log('\n❌ Some tests failed. Please check the report for details.'.red.bold);
            process.exit(1);
        } else {
            console.log('\n✅ All tests passed! Your backend is working correctly.'.green.bold);
            process.exit(0);
        }
    } catch (error) {
        console.error('Error running tests:', error);
        process.exit(1);
    }
}

// Run tests
runTests();