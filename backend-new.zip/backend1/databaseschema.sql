-- University Resource Management System Database Schema


CREATE DATABASE IF NOT EXISTS university_resources;
USE university_resources;

-- Drop tables if they exist
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS user_sessions;
DROP TABLE IF EXISTS password_resets;
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS resource_schedule;
DROP TABLE IF EXISTS equipment_inventory;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS resources;
DROP TABLE IF EXISTS users;

-- 1. Users Table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    registration_no VARCHAR(100) UNIQUE,
    department VARCHAR(100),
    faculty VARCHAR(100),
    role ENUM('student', 'lecturer', 'admin', 'staff', 'researcher') DEFAULT 'student',
    academic_year VARCHAR(50),
    phone VARCHAR(20),
    profile_photo VARCHAR(500),                 -- UPDATED column name
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_department (department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Resources Table
CREATE TABLE resources (
    resource_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    type ENUM('laboratory', 'lecture-hall', 'auditorium', 'meeting-room', 'equipment') NOT NULL,
    faculty VARCHAR(100) NOT NULL,
    building VARCHAR(255) NOT NULL,
    capacity INT NOT NULL,
    location VARCHAR(255),
    equipment JSON,
    status ENUM('available', 'occupied', 'maintenance', 'reserved') DEFAULT 'available',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_faculty (faculty),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Bookings Table
CREATE TABLE bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    resource_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    reason ENUM('class', 'exam', 'meeting', 'workshop', 'event', 'research', 'other') NOT NULL,
    purpose TEXT,
    requirements TEXT,
    attendees INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (resource_id) REFERENCES resources(resource_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_resource_id (resource_id),
    INDEX idx_date (date),
    INDEX idx_status (status),
    INDEX idx_date_time (date, start_time, end_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Notifications Table
CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    type ENUM('approved', 'pending', 'rejected', 'registration', 'reminder', 'system') NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    priority ENUM('high', 'medium', 'low') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Resource Schedule Table
CREATE TABLE resource_schedule (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    resource_id INT NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status ENUM('available', 'booked', 'maintenance', 'lunch') NOT NULL,
    booking_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resource_id) REFERENCES resources(resource_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL,
    INDEX idx_resource_date (resource_id, date),
    INDEX idx_date_time (date, start_time, end_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Equipment Inventory Table
CREATE TABLE equipment_inventory (
    equipment_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    quantity_available INT DEFAULT 0,
    quantity_total INT DEFAULT 0,
    location VARCHAR(255),
    status ENUM('available', 'checked_out', 'maintenance') DEFAULT 'available',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Feedback Table
CREATE TABLE feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    contact_number VARCHAR(20),
    feedback_text TEXT NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Password Resets Table
CREATE TABLE password_resets (
    reset_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. User Sessions Table
CREATE TABLE user_sessions (
    session_id VARCHAR(255) PRIMARY KEY,
    user_id INT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Audit Logs Table
CREATE TABLE audit_logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    table_name VARCHAR(100) NOT NULL,
    record_id INT NOT NULL,
    action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    old_values JSON,
    new_values JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_table_record (table_name, record_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user
INSERT INTO users (full_name, email, password_hash, role, department, faculty, is_active) 
VALUES (
    'System Administrator',
    'admin@university.edu',
    '$2a$10$YourHashedPasswordHere',
    'admin',
    'IT Department',
    'Administration',
    TRUE
);

-- Insert sample resources
INSERT INTO resources (name, type, faculty, building, capacity, location, equipment, status, description) VALUES
('Computer Lab A-301', 'laboratory', 'engineering', 'Engineering Building A', 40, 'Floor 3, Room 301', '["Computers", "Projector", "Whiteboard", "Air Conditioning"]', 'available', 'Modern computer laboratory with 40 workstations'),
('Computer Lab B-201', 'laboratory', 'engineering', 'Engineering Building B', 35, 'Floor 2, Room 201', '["Computers", "Projector", "Whiteboard"]', 'available', 'Computer laboratory for programming courses'),
('Physics Lab 101', 'laboratory', 'science', 'Science Building', 30, 'Floor 1, Room 101', '["Lab Equipment", "Safety Gear", "Projector"]', 'available', 'Physics laboratory with modern equipment'),
('Chemistry Lab 205', 'laboratory', 'science', 'Science Building', 25, 'Floor 2, Room 205', '["Lab Equipment", "Fume Hoods", "Safety Equipment"]', 'available', 'Chemistry laboratory with safety features'),
('Main Lecture Hall', 'lecture-hall', 'general', 'Main Building', 200, 'Ground Floor', '["Projector", "Sound System", "Microphone", "Air Conditioning"]', 'available', 'Large lecture hall for major events'),
('Lecture Hall A', 'lecture-hall', 'engineering', 'Engineering Building A', 100, 'Floor 1', '["Projector", "Sound System", "Whiteboard"]', 'available', 'Engineering faculty lecture hall'),
('Lecture Hall B', 'lecture-hall', 'science', 'Science Building', 80, 'Floor 3', '["Projector", "Sound System", "Whiteboard"]', 'available', 'Science faculty lecture hall'),
('Lecture Hall C', 'lecture-hall', 'business', 'Business Building', 90, 'Floor 2', '["Projector", "Sound System", "Whiteboard"]', 'available', 'Business faculty lecture hall'),
('Grand Auditorium', 'auditorium', 'general', 'Main Building', 500, 'Ground Floor', '["Stage", "Sound System", "Lighting", "Projector", "Air Conditioning"]', 'available', 'Main auditorium for university events'),
('Mini Auditorium', 'auditorium', 'general', 'Student Center', 150, 'Floor 2', '["Sound System", "Projector", "Stage"]', 'available', 'Smaller auditorium for departmental events'),
('Meeting Room 1', 'meeting-room', 'general', 'Administration Building', 15, 'Floor 3, Room 301', '["Conference Table", "Projector", "Whiteboard", "Video Conferencing"]', 'available', 'Executive meeting room'),
('Meeting Room 2', 'meeting-room', 'general', 'Administration Building', 12, 'Floor 3, Room 302', '["Conference Table", "Projector", "Whiteboard"]', 'available', 'Standard meeting room'),
('Library Study Room 1', 'meeting-room', 'general', 'Library Building', 8, 'Floor 2', '["Study Table", "Whiteboard"]', 'available', 'Small group study room'),
('Library Study Room 2', 'meeting-room', 'general', 'Library Building', 10, 'Floor 2', '["Study Table", "Whiteboard", "Computer"]', 'available', 'Medium group study room'),
('Seminar Room A', 'meeting-room', 'engineering', 'Engineering Building A', 30, 'Floor 4, Room 401', '["Projector", "Whiteboard", "Sound System"]', 'available', 'Seminar and workshop room'),
('Research Lab 1', 'laboratory', 'research', 'Research Center', 20, 'Floor 1', '["Research Equipment", "Computers", "Storage"]', 'available', 'General research laboratory');

-- Insert sample equipment inventory
INSERT INTO equipment_inventory (name, type, quantity_available, quantity_total, location, status, description) VALUES
('Laptop', 'Computer', 25, 30, 'IT Department', 'available', 'Dell Latitude laptops for checkout'),
('Projector', 'Presentation', 15, 20, 'IT Department', 'available', 'Portable projectors'),
('Microphone', 'Audio', 10, 12, 'IT Department', 'available', 'Wireless microphones'),
('Camera', 'Video', 5, 8, 'Media Center', 'available', 'Digital cameras for events'),
('Whiteboard', 'Teaching', 20, 25, 'Storage', 'available', 'Portable whiteboards');

-- Create views
CREATE OR REPLACE VIEW available_resources AS
SELECT 
    r.*,
    COUNT(DISTINCT b.booking_id) as total_bookings
FROM resources r
LEFT JOIN bookings b ON r.resource_id = b.resource_id 
    AND b.status = 'approved'
    AND b.date >= CURDATE()
WHERE r.status = 'available'
GROUP BY r.resource_id;

CREATE OR REPLACE VIEW upcoming_bookings AS
SELECT 
    b.*,
    u.full_name as user_name,
    u.email as user_email,
    r.name as resource_name,
    r.type as resource_type,
    r.building as resource_building
FROM bookings b
JOIN users u ON b.user_id = u.user_id
JOIN resources r ON b.resource_id = r.resource_id
WHERE b.date >= CURDATE()
    AND b.status IN ('approved', 'pending')
ORDER BY b.date, b.start_time;

-- Create stored procedure
DELIMITER //

CREATE PROCEDURE check_resource_availability(
    IN p_resource_id INT,
    IN p_date DATE,
    IN p_start_time TIME,
    IN p_end_time TIME
)
BEGIN
    SELECT COUNT(*) as conflicts
    FROM bookings
    WHERE resource_id = p_resource_id
        AND date = p_date
        AND status IN ('approved', 'pending')
        AND (
            (start_time <= p_start_time AND end_time > p_start_time)
            OR (start_time < p_end_time AND end_time >= p_end_time)
            OR (start_time >= p_start_time AND end_time <= p_end_time)
        );
END //

DELIMITER ;

-- Create triggers
DELIMITER //

CREATE TRIGGER after_booking_insert
AFTER INSERT ON bookings
FOR EACH ROW
BEGIN
    IF NEW.status = 'approved' AND NEW.date = CURDATE() THEN
        UPDATE resources 
        SET status = 'reserved' 
        WHERE resource_id = NEW.resource_id;
    END IF;
END //

CREATE TRIGGER after_booking_update
AFTER UPDATE ON bookings
FOR EACH ROW
BEGIN
    IF NEW.status = 'approved' AND NEW.date = CURDATE() THEN
        UPDATE resources 
        SET status = 'reserved' 
        WHERE resource_id = NEW.resource_id;
    ELSEIF OLD.status = 'approved' AND NEW.status IN ('cancelled', 'rejected') THEN
        UPDATE resources 
        SET status = 'available' 
        WHERE resource_id = NEW.resource_id
        AND NOT EXISTS (
            SELECT 1 FROM bookings 
            WHERE resource_id = NEW.resource_id 
            AND date = CURDATE() 
            AND status = 'approved'
            AND booking_id != NEW.booking_id
        );
    END IF;
END //

DELIMITER ;

SELECT 'Database schema created successfully!' as message;
